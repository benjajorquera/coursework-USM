Antes de ejecutar el notebook deberás configurar adecuadamente el ambiente anaconda para poder usar el lenguaje R con Python.
Si ya tienes R-magic en Jupyter Notebook ignora este paso.

Abre una terminal y ejecuta:
$sudo apt-get install python3-rpy2
$conda install -m rpy

Descomprime el archivador Jorquera_Lab4.zip y abre el archivo Lab4.ipynb
