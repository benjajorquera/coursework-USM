Instrucciones:

cd /Jorquera_Lab3
jupyter notebook
