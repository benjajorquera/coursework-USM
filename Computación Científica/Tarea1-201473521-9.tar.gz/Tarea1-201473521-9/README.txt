- Librer�as utilizadas:

numpy
matplotlib.pyplot
ipywidgets
math

- M�dulos:

https://github.com/tclaudioe/Scientific-Computing/blob/master/SC1/04_roots_of_1D_equations.ipynb

- Estudiante:

Benjam�n Alberto Jorquera Jorquera
201473521-9