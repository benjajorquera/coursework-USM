Benjamin Jorquera J. 201473521-9
Macarena Hidalgo A. 201473608-8

instrucciones de uso:
 por consola poner MAKE y listo disfrute del juego.
	