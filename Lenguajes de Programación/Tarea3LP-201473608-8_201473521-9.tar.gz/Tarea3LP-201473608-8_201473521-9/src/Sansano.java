import java.util.ArrayList;

public class Sansano {
    private int prioridad = 3000;
    private String jugador;
    private ArrayList<carta> mazo = new ArrayList<>();

    int getPrioridad(){
        return prioridad;
    }
    public void setPrioridad(int prioridad) {
        this.prioridad = prioridad;
    }

    public String getJugador() {
        return jugador;
    }

    public void setJugador(String jugador) {
        this.jugador = jugador;
    }

    public ArrayList<carta> getMazo() {
        return mazo;
    }

    public void Agregar_Carta(carta Card){
        mazo.ensureCapacity(mazo.size()+1);
        mazo.add(Card);
    }

    public void Eliminar_Carta(){
        mazo.remove(mazo.get(mazo.size()));
        mazo.trimToSize();
    }
}