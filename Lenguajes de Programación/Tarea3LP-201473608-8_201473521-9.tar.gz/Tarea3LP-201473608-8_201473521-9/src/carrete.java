/**
 * Created by Samsung on 19-10-2016.
 */
public class carrete extends carta {
    private int curacion;

    public carrete(String nom, String des, int cura){
        descripcion = des;
        nombre_carta = nom;
        curacion=cura;
    }

    private int carretear(Sansano sansanito){
        int prio = sansanito.getPrioridad();
        prio +=curacion;
        if(prio<3000) sansanito.setPrioridad(prio);
        else sansanito.setPrioridad(3000);
        return sansanito.getPrioridad();
    }
    public void activar(Sansano sansanito, String decision){
        this.carretear(sansanito);
    }
}
