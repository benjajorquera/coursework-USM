/**
 * Created by Samsung on 19-10-2016.
 */
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Created by maca on 19-10-2016.
 */
public class juego extends Application {

    public void start(Stage primaryStage) {
        try {
            Pane page = FXMLLoader.load(juego.class.getResource("interfaz.fxml"));
            Scene scene = new Scene(page);
            primaryStage.setScene(scene);
            primaryStage.setTitle("Bienvenido a SansaStone!");
            primaryStage.show();
        }
        catch (Exception ex) {
            Logger.getLogger(juego.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public static void main(String[] args) {
        launch(args);
    }

}