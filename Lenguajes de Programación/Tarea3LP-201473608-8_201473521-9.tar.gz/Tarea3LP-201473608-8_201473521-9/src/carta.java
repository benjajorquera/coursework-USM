/**
 * Created by Samsung on 19-10-2016.
 */
abstract class carta {
    String nombre_carta;
    String descripcion;
    abstract void activar(Sansano sansanito, String decision);
    public String getNombre(){
        return nombre_carta;
    }
    public String getDescripcion(){
        return descripcion;
    }
}
