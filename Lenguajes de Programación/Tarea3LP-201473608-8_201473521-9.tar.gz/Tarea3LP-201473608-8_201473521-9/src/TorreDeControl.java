import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.scene.control.Label;
import javafx.scene.control.Tab;
import javafx.scene.control.TabPane;

import java.net.JarURLConnection;
import java.util.Random;
import java.util.Collections;

import java.awt.*;
import javax.swing.*;

public class TorreDeControl {

    public TabPane juego;
    public Tab menu;
    public Tab m1;
    public Tab m2;
    public Label turnosm1;
    public Label priori_opo;
    public Label cantidad_cartas_opo;
    public Label estado_opo;
    public Label prioridad_jugador_m1;
    public Label cantidad_cartas_jugador_m1;
    public Label nombre_carta_m1;
    public Label descripcion_carta_m1;
    public int turno = 0;


    public duelo partida = new duelo();
    public Sansano Jugador1 = new Sansano();
    public Sansano Jugador2 = new Sansano();

    public void modoUnJugador(ActionEvent actionEvent) {
        juego.getSelectionModel().select(m1);
        Jugador1.setJugador("ingresar pantalla");
        Jugador2.setJugador("Oponente");
        curso mate = new curso(550, 200, "Matematicas", "Ataca 550/Cura 200 puntos de prioridad.");
        curso fisica = new curso(450,150,"Fisica","ataca450/cura 150 ptos de prioridad");
        curso LP = new curso(510,180,"LP", "ataca 510 /cura 180 ptos de prioridad");
        curso progra = new curso(110,300,"Progra", "ataca 110 /cura 300 ptos de prioridad");
        curso ED = new curso(470,160,"ED","ataca 470 /cura 160 ptos de prioridad");
        curso EDD = new curso(430,120,"EDD", "ataca430 / cura 120 ptos de prioridad");
        Profesor bahamondes = new Profesor("BAHAMONDES","reduce 420 ptos. de prioridad",420);
        Profesor maxaraya = new Profesor("MAX ARAYA","reduce 350 ptos. de prioridad",350);
        Profesor cifuentes = new Profesor("CIFUENTES","reduce 390 ptos. de prioridad",390);
        Profesor maxrivera = new Profesor("MAX RIVERA","reduce 280 ptos. de prioridad",280);
        carrete cerrito = new carrete("cerrito","recupera 55 ptos. de prioridad",55);
        carrete inter = new carrete("inter mechon","recupera 80 ptos. de prioridad",80);
        carrete sansafonda = new carrete("sansafonda","recupera 100 ptos. de prioridad",100);
        carrete semanasansana = new carrete("semana sansana","recupera 150 ptos. de prioridad",150);
        carrete bloquelibre = new carrete("bloque libre","recupera 30 ptos. de prioridad",30);
        carrete ombligo = new carrete("fiesta ombligo","recupera 125 ptos. de prioridad",125);

        //se crea el mazo j1
        Jugador1.Agregar_Carta(mate);
        for(int i=0;i<4;i++){
        Jugador1.Agregar_Carta(fisica);}
        Jugador1.Agregar_Carta(LP);
        Jugador1.Agregar_Carta(LP);
        for(int i=0;i<6;i++){
            Jugador1.Agregar_Carta(progra);
        }
        for(int i=0;i<3;i++){
            Jugador1.Agregar_Carta(ED);
        }
        for(int i=0;i<4;i++){
            Jugador1.Agregar_Carta(EDD);
        }
        Jugador1.Agregar_Carta(bahamondes);
        Jugador1.Agregar_Carta(maxaraya);
        Jugador1.Agregar_Carta(cifuentes);
        Jugador1.Agregar_Carta(maxrivera);
        Jugador1.Agregar_Carta(cerrito);
        Jugador1.Agregar_Carta(inter);
        Jugador1.Agregar_Carta(sansafonda);
        Jugador1.Agregar_Carta(semanasansana);
        Jugador1.Agregar_Carta(bloquelibre);
        Jugador1.Agregar_Carta(ombligo);
        long seed = System.nanoTime();
        Collections.shuffle(Jugador1.getMazo(), new Random(seed));

        //se crea el mazo j2
        Jugador2.Agregar_Carta(mate);
        for(int i=0;i<4;i++){
            Jugador2.Agregar_Carta(fisica);}
        Jugador2.Agregar_Carta(LP);
        Jugador2.Agregar_Carta(LP);
        for(int i=0;i<6;i++){
            Jugador2.Agregar_Carta(progra);
        }
        for(int i=0;i<3;i++){
            Jugador2.Agregar_Carta(ED);
        }
        for(int i=0;i<4;i++){
            Jugador2.Agregar_Carta(EDD);
        }
        Jugador2.Agregar_Carta(bahamondes);
        Jugador2.Agregar_Carta(maxaraya);
        Jugador2.Agregar_Carta(cifuentes);
        Jugador2.Agregar_Carta(maxrivera);
        Jugador2.Agregar_Carta(cerrito);
        Jugador2.Agregar_Carta(inter);
        Jugador2.Agregar_Carta(sansafonda);
        Jugador2.Agregar_Carta(semanasansana);
        Jugador2.Agregar_Carta(bloquelibre);
        Jugador2.Agregar_Carta(ombligo);
        long seed2 = System.nanoTime();
        Collections.shuffle(Jugador2.getMazo(), new Random(seed2));
        //comienza juego
        partida.pasarTurno();
        turnosm1.setText("turno: " + String.valueOf(partida.getTurnos()));
        priori_opo.setText("prioridad: " + String.valueOf(Jugador2.getPrioridad()));
        cantidad_cartas_opo.setText("cartas: " + String.valueOf(Jugador2.getMazo().size()));
        estado_opo.setText("estado: ");
        prioridad_jugador_m1.setText("prioridad: " + String.valueOf(Jugador1.getPrioridad()));
        cantidad_cartas_jugador_m1.setText("cartas: " + String.valueOf(Jugador1.getMazo().size()));
        nombre_carta_m1.setText("Nombre: " + String.valueOf(Jugador1.getMazo().get(Jugador1.getMazo().size()-1).getNombre()));
        descripcion_carta_m1.setText("Descripcion: " + String.valueOf(Jugador1.getMazo().get(Jugador1.getMazo().size()-1).getDescripcion()));
    }

    public void conUnAmigo(ActionEvent actionEvent) {
        juego.getSelectionModel().select(m2);
        Jugador1.setJugador("ingresar pantalla");
        Jugador2.setJugador("pichula");
    }

   public void terminar_turno(ActionEvent actionEvent) {
           if(Jugador1.getMazo().get(Jugador1.getMazo().size()-1) instanceof carrete || Jugador1.getMazo().get(Jugador1.getMazo().size()-1) instanceof Profesor){
               if(turno!=1){
           Jugador1.getMazo().get(Jugador1.getMazo().size()-1).activar(Jugador1, "");
           Jugador1.getMazo().remove(Jugador1.getMazo().size()-1);}
           }

           if(Jugador2.getMazo().get(Jugador2.getMazo().size()-1) instanceof curso){
               Random rand = new Random();
               int  n = rand.nextInt(2) + 1;
               if(n==1){ Jugador2.getMazo().get(Jugador2.getMazo().size()-1).activar(Jugador2, "Aprobar");
                   estado_opo.setText("estado: Oponente uso " + String.valueOf(Jugador2.getMazo().get(Jugador2.getMazo().size()-1).getNombre()));
                   Jugador2.getMazo().remove(Jugador2.getMazo().size()-1);}
               else {Jugador2.getMazo().get(Jugador2.getMazo().size()-1).activar(Jugador1, "Reprobar");
                   estado_opo.setText("estado: Oponente uso " + String.valueOf(Jugador2.getMazo().get(Jugador2.getMazo().size()-1).getNombre()));
                   Jugador2.getMazo().remove(Jugador2.getMazo().size()-1);}
               }
           else{
               Jugador2.getMazo().get(Jugador2.getMazo().size()-1).activar(Jugador2, "");
               estado_opo.setText("estado: Oponente uso " + String.valueOf(Jugador2.getMazo().get(Jugador2.getMazo().size()-1).getNombre()));
               Jugador2.getMazo().remove(Jugador2.getMazo().size()-1);
           }
       turno =0;


       partida.pasarTurno();
       turnosm1.setText("turno: " + String.valueOf(partida.getTurnos()));
       priori_opo.setText("prioridad: " + String.valueOf(Jugador2.getPrioridad()));
       cantidad_cartas_opo.setText("cartas: " + String.valueOf(Jugador2.getMazo().size()));
       prioridad_jugador_m1.setText("prioridad: " + String.valueOf(Jugador1.getPrioridad()));
       cantidad_cartas_jugador_m1.setText("cartas: " + String.valueOf(Jugador1.getMazo().size()));
       nombre_carta_m1.setText("Nombre: " + String.valueOf(Jugador1.getMazo().get(Jugador1.getMazo().size()-1).getNombre()));
       descripcion_carta_m1.setText("Descripcion: " + String.valueOf(Jugador1.getMazo().get(Jugador1.getMazo().size()-1).getDescripcion()));


    }

    public void atacar(ActionEvent actionEvent) {
        Jugador1.getMazo().get(Jugador1.getMazo().size()-1).activar(Jugador2, "Reprobar");
        Jugador1.getMazo().remove(Jugador1.getMazo().size()-1);
        turnosm1.setText("turno: " + String.valueOf(partida.getTurnos()));
        priori_opo.setText("prioridad: " + String.valueOf(Jugador2.getPrioridad()));
        cantidad_cartas_opo.setText("cartas: " + String.valueOf(Jugador2.getMazo().size()));
        prioridad_jugador_m1.setText("prioridad: " + String.valueOf(Jugador1.getPrioridad()));
        cantidad_cartas_jugador_m1.setText("cartas: " + String.valueOf(Jugador1.getMazo().size()));
        turno=1;

    }

    public void curar(ActionEvent actionEvent) {
        Jugador1.getMazo().get(Jugador1.getMazo().size()-1).activar(Jugador1, "Aprobar");
        Jugador1.getMazo().remove(Jugador1.getMazo().size()-1);
        turnosm1.setText("turno: " + String.valueOf(partida.getTurnos()));
        priori_opo.setText("prioridad: " + String.valueOf(Jugador2.getPrioridad()));
        cantidad_cartas_opo.setText("cartas: " + String.valueOf(Jugador2.getMazo().size()));
        prioridad_jugador_m1.setText("prioridad: " + String.valueOf(Jugador1.getPrioridad()));
        cantidad_cartas_jugador_m1.setText("cartas: " + String.valueOf(Jugador1.getMazo().size()));
        turno=1;
    }

    public void atacar2(ActionEvent actionEvent) {

    }

    public void curar2(ActionEvent actionEvent) {
    }

    public void terminar_turno2(ActionEvent actionEvent) {
    }
}
