/**
 * Created by Samsung on 19-10-2016.
 */
public class curso extends carta {
    private int ataque;
    private int defensa;


    public curso(int atack, int defence,String nombre, String descrip){
        ataque = atack;
        defensa = defence;
        nombre_carta= nombre;
        descripcion=descrip;
    }
    private int aprobar (Sansano sansanito){
        int prio = sansanito.getPrioridad();
        prio += defensa;
        if (prio<3000) sansanito.setPrioridad(prio);
        else sansanito.setPrioridad(3000);
        return sansanito.getPrioridad();
    }
    private int reprobar(Sansano sansanito){
        int prio = sansanito.getPrioridad();
        prio -= ataque;
        if (prio>0) sansanito.setPrioridad(prio);
        else sansanito.setPrioridad(0);
        return sansanito.getPrioridad();
    }
    public void activar(Sansano sansanito, String decision){
        if (decision.equals("Aprobar"))
            this.aprobar(sansanito);
        else if(decision.equals("Reprobar"))
            this.reprobar(sansanito);
    }

}