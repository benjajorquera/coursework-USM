/**
 * Created by Samsung on 19-10-2016.
 */
public class duelo {
    private int turnos = 0;
    private String ganador;

    public int getTurnos() {
        return turnos;
    }

    public void pasarTurno() {
        this.turnos += 1;
    }

    public String getGanador() {
        return ganador;
    }

    public void setGanador(String ganador) {
        this.ganador = ganador;
    }
}

