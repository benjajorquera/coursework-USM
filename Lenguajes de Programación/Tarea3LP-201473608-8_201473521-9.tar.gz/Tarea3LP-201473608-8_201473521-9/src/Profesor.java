/**
 * Created by Samsung on 19-10-2016.
 */
public class Profesor extends carta {
    private int dano;
    public Profesor(String nom, String des, int danno){
        descripcion = des;
        nombre_carta = nom;
        dano=danno;
    }
    private int recorregir(Sansano sansanito){
        int prio = sansanito.getPrioridad();
        prio -= dano;
        if (prio>0) sansanito.setPrioridad(prio);
        else sansanito.setPrioridad(0);
        return sansanito.getPrioridad();
    }
    public void activar(Sansano sansanito, String decision){
        this.recorregir(sansanito);
    }
}
