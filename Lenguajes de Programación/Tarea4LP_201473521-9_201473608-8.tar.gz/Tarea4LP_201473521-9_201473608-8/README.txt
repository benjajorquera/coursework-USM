Nombre | Rol

Macarena Hidalgo Ahumada | 201473608-8
Cristian Vallejos P�rez  | 201473551-0

Instrucciones de uso:

1.- Se debe tener instalada la versi�n 6.5 de DrRacket para la �ptima ejecuci�n de los programas.
2.- Para correr cada programa, debe ejecutarlo con el IDE DrRacket,
    dar click en Run y ejecutar las pruebas en la consola del int�rprete.